## COSC302 Project 2 Time by Mode Table
### 09.18.2024
### Nic Dawson, Jules Prater, Mabry Runnels, and Ryan Wolpert

| Mode          | Size        | Elapsed Time (sec)|
| ------------- |-------------|-------------------|
| STL           | 10          | 0.002             |
| STL           | 100         | 0.004             |
| STL           | 1000        | 0.005             |
| STL           | 10000       | 0.013             |
| STL           | 100000      | 0.096             |
| STL           | 1000000     | 5.999             |
| STL           | 10000000    | 01:08.3           |
| QSORT         | 10          | 0.001             |
| QSORT         | 100         | 0.002             |
| QSORT         | 1000        | 0.003             |
| QSORT         | 10000       | 0.011             |
| QSORT         | 100000      | 0.096             |
| QSORT         | 1000000     | 4.95              |
| QSORT         | 10000000    | 54.957            |
| MERGE         | 10          | 0.001             |
| MERGE         | 100         | 0.002             |
| MERGE         | 1000        | 0.002             |
| MERGE         | 10000       | 0.011             |
| MERGE         | 100000      | 0.098             |
| MERGE         | 1000000     | 4.641             |
| MERGE         | 10000000    | 54.414            |
| QUICK         | 10          | 0.001             |
| QUICK         | 100         | 0.002             |
| QUICK         | 1000        | 0.002             |
| QUICK         | 10000       | 0.011             |
| QUICK         | 100000      | 0.097             |
| QUICK         | 1000000     | 4.625             |
| QUICK         | 10000000    | 55.851            |
